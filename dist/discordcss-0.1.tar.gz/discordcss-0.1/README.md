# discord.css
### A simple python package to use css for discord api

## Installation
run ```git clone https://github.com/CloudyDaKing/discord.css```
then change ``
use discordcss {css file path} to run the css file

## Documentation

i cant be asked to make a documentation so just look at the app.css file, someone else can do it if they want
havent tested onleave and onjoin yet so no clue if they work
